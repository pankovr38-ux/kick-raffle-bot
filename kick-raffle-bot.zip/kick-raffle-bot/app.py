"""
Kick Raffle Bot — Бот для розыгрышей на канале Kick
Канал: rost-is-live
Функционал:
- Подключение к чату Kick в реальном времени через WebSocket (Pusher)
- Сбор уникальных участников (каждый пользователь только один раз)
- Настраиваемое ключевое слово для участия
- Управление через веб-интерфейс (старт/стоп/выбор победителя/сброс)
- Анимация выбора победителя с конфетти
"""

import json
import os
import random
import threading
import time
from collections import OrderedDict

import requests
from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
import websocket

# =============================================================================
# НАСТРОЙКИ — можно изменить или задать через переменные окружения
# =============================================================================
CHANNEL_SLUG = os.environ.get("KICK_CHANNEL", "rost-is-live")
PARTICIPATION_KEYWORD = os.environ.get("PARTICIPATION_KEYWORD", "!участвую")
MAX_PARTICIPANTS = int(os.environ.get("MAX_PARTICIPANTS", "10000"))
SECRET_KEY = os.environ.get("SECRET_KEY", "rost-is-live-raffle-secret-key-change-me")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")  # пустой = без пароля
PORT = int(os.environ.get("PORT", "5000"))
HOST = os.environ.get("HOST", "0.0.0.0")
DEBUG = os.environ.get("DEBUG", "false").lower() == "true"

# =============================================================================
# ИНИЦИАЛИЗАЦИЯ
# =============================================================================
app = Flask(__name__)
app.config["SECRET_KEY"] = SECRET_KEY
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

# Состояние бота
participants = OrderedDict()  # username -> {added_at, color}
raffle_active = False
current_keyword = PARTICIPATION_KEYWORD.lower()
ws_connection = None
ws_connected = False

# Цвета для аватаров
AVATAR_COLORS = [
    "#ef4444", "#f97316", "#eab308", "#22c55e", "#06b6d4",
    "#3b82f6", "#8b5cf6", "#ec4899", "#f43f5e", "#14b8a6",
]


def avatar_color(username: str) -> str:
    """Определяет цвет аватара по имени пользователя."""
    h = 0
    for ch in username:
        h = ord(ch) + ((h << 5) - h)
    return AVATAR_COLORS[abs(h) % len(AVATAR_COLORS)]


def state_payload():
    """Формирует текущее состояние для отправки клиентам."""
    names = list(participants.keys())
    return {
        "active": raffle_active,
        "count": len(participants),
        "keyword": current_keyword,
        "channel": CHANNEL_SLUG,
        "participants": [
            {"username": n, "color": participants[n]["color"]} for n in names
        ],
        "password_protected": bool(ADMIN_PASSWORD),
    }


# =============================================================================
# ПОДКЛЮЧЕНИЕ К ЧАТУ KICK (PUSHER WEBSOCKET)
# =============================================================================
def get_chatroom_id() -> str:
    """Получает ID чат-комнаты канала через публичное API Kick."""
    try:
        resp = requests.get(
            f"https://kick.com/api/v2/channels/{CHANNEL_SLUG}",
            headers={"User-Agent": "Mozilla/5.0 (Kick Raffle Bot)"},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        return str(data["chatroom"]["id"])
    except Exception as e:
        print(f"[ERROR] Не удалось получить chatroom_id: {e}")
        raise


def on_ws_open(ws):
    global ws_connected
    ws_connected = True
    print("[KICK] WebSocket подключен")
    try:
        chatroom_id = get_chatroom_id()
        print(f"[KICK] Подписываемся на канал chatrooms.{chatroom_id}.v1")
        ws.send(
            json.dumps(
                {
                    "event": "pusher:subscribe",
                    "data": {"channel": f"chatrooms.{chatroom_id}.v1"},
                }
            )
        )
        socketio.emit("connection_status", {"connected": True, "channel": CHANNEL_SLUG})
    except Exception as e:
        print(f"[ERROR] Ошибка подписки на канал: {e}")


def on_ws_message(ws, message):
    global raffle_active, current_keyword, participants
    try:
        data = json.loads(message)
        event = data.get("event", "")

        # Сообщение в чате
        if event == "App\\Events\\ChatMessageEvent":
            payload = json.loads(data["data"])
            sender = payload.get("sender", {}).get("username", "unknown")
            content = payload.get("content", "")

            # Отправляем сообщение в веб-интерфейс
            socketio.emit(
                "chat_message",
                {"username": sender, "content": content, "color": avatar_color(sender)},
            )

            # Проверяем участие в розыгрыше
            if raffle_active and current_keyword and current_keyword in content.lower():
                if sender not in participants and len(participants) < MAX_PARTICIPANTS:
                    participants[sender] = {
                        "added_at": time.time(),
                        "color": avatar_color(sender),
                    }
                    socketio.emit(
                        "new_participant",
                        {
                            "username": sender,
                            "color": participants[sender]["color"],
                            "count": len(participants),
                        },
                    )
                    print(f"[RAFFLE] + {sender} (всего: {len(participants)})")

        elif event == "pusher:connection_established":
            print("[KICK] Pusher сессия установлена")
        elif event == "pusher_internal:subscription_succeeded":
            print("[KICK] Подписка на канал успешна")

    except json.JSONDecodeError:
        pass
    except Exception as e:
        print(f"[ERROR] Ошибка обработки сообщения: {e}")


def on_ws_close(ws, close_status_code, close_msg):
    global ws_connected
    ws_connected = False
    print(f"[KICK] WebSocket отключен (код: {close_status_code})")
    socketio.emit("connection_status", {"connected": False})


def on_ws_error(ws, error):
    print(f"[KICK] WebSocket ошибка: {error}")


def kick_websocket_loop():
    """Основной цикл подключения к Kick с автоматическим переподключением."""
    global ws_connection
    pusher_url = (
        "wss://ws-us2.pusher.com/app/eb1d5f283081a78b932c"
        "?protocol=7&client=js&version=7.6.0&flash=false"
    )
    while True:
        try:
            print("[KICK] Устанавливаем соединение...")
            ws_connection = websocket.WebSocketApp(
                pusher_url,
                on_open=on_ws_open,
                on_message=on_ws_message,
                on_close=on_ws_close,
                on_error=on_ws_error,
            )
            ws_connection.run_forever(ping_interval=30, ping_timeout=10)
        except Exception as e:
            print(f"[ERROR] WebSocket упал: {e}")
        print("[KICK] Переподключение через 5 секунд...")
        time.sleep(5)


# Запускаем WebSocket в фоновом потоке
threading.Thread(target=kick_websocket_loop, daemon=True).start()


# =============================================================================
# WEB-МАРШРУТЫ
# =============================================================================
@app.route("/")
def index():
    return render_template(
        "index.html",
        channel=CHANNEL_SLUG,
        keyword=current_keyword,
        password_protected=bool(ADMIN_PASSWORD),
    )


@app.route("/health")
def health():
    return {"status": "ok", "ws_connected": ws_connected, "participants": len(participants)}


# =============================================================================
# SOCKET.IO СОБЫТИЯ (УПРАВЛЕНИЕ РОЗЫГРЫШЕМ)
# =============================================================================
@socketio.on("connect")
def on_connect():
    emit("state", state_payload())
    emit("connection_status", {"connected": ws_connected, "channel": CHANNEL_SLUG})


@socketio.on("get_state")
def handle_get_state():
    emit("state", state_payload())


def check_password(data):
    """Проверяет пароль, если он установлен."""
    if not ADMIN_PASSWORD:
        return True
    return isinstance(data, dict) and data.get("password") == ADMIN_PASSWORD


@socketio.on("start_raffle")
def handle_start(data=None):
    global raffle_active, current_keyword, participants
    if not check_password(data):
        emit("error", {"message": "Неверный пароль"})
        return
    kw = (data or {}).get("keyword", "") if isinstance(data, dict) else ""
    if kw:
        current_keyword = kw.strip().lower()
    participants.clear()
    raffle_active = True
    print(f"[RAFFLE] Розыгрыш ЗАПУЩЕН. Ключевое слово: '{current_keyword}'")
    emit("state", state_payload(), broadcast=True)


@socketio.on("stop_raffle")
def handle_stop(data=None):
    global raffle_active
    if not check_password(data):
        emit("error", {"message": "Неверный пароль"})
        return
    raffle_active = False
    print(f"[RAFFLE] Розыгрыш ОСТАНОВЛЕН. Участников: {len(participants)}")
    emit("state", state_payload(), broadcast=True)


@socketio.on("pick_winner")
def handle_pick(data=None):
    global raffle_active
    if not check_password(data):
        emit("error", {"message": "Неверный пароль"})
        return
    raffle_active = False
    names = list(participants.keys())
    if not names:
        emit("no_participants")
        return
    winner = random.choice(names)
    print(f"[RAFFLE] ПОБЕДИТЕЛЬ: {winner} (из {len(names)})")
    emit(
        "winner_selected",
        {
            "winner": winner,
            "color": participants[winner]["color"],
            "total": len(names),
        },
        broadcast=True,
    )
    emit("state", state_payload(), broadcast=True)


@socketio.on("reset_raffle")
def handle_reset(data=None):
    global raffle_active, participants
    if not check_password(data):
        emit("error", {"message": "Неверный пароль"})
        return
    participants.clear()
    raffle_active = False
    print("[RAFFLE] Розыгрыш СБРОШЕН")
    emit("raffle_reset", broadcast=True)
    emit("state", state_payload(), broadcast=True)


@socketio.on("set_keyword")
def handle_set_keyword(data):
    global current_keyword
    if not check_password(data):
        emit("error", {"message": "Неверный пароль"})
        return
    kw = (data or {}).get("keyword", "").strip()
    if kw:
        current_keyword = kw.lower()
        print(f"[RAFFLE] Ключевое слово изменено на: '{current_keyword}'")
        emit("state", state_payload(), broadcast=True)


# =============================================================================
# ЗАПУСК
# =============================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  KICK RAFFLE BOT — Бот для розыгрышей")
    print(f"  Канал:    {CHANNEL_SLUG}")
    print(f"  Ключевое: {current_keyword}")
    print(f"  Пароль:   {'установлен' if ADMIN_PASSWORD else 'не требуется'}")
    print(f"  Адрес:    http://{HOST}:{PORT}")
    print("=" * 60)
    socketio.run(app, host=HOST, port=PORT, debug=DEBUG, allow_unsafe_werkzeug=True)
